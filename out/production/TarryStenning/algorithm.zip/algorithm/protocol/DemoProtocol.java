package algorithm.protocol;

import algorithm.resource.TarryMessage;

import java.io.IOException;
import java.util.Map;

/**
 * Created by cuongpham on 11/29/15.
 */
public class DemoProtocol extends Thread{
    private StenningProtocol stenningProtocol;
    private String name;
    private int myPort;


    public DemoProtocol(String name) {
        super(name);
        myPort = Integer.parseInt(name);
        stenningProtocol = new StenningProtocol(myPort);
    }

    public void run() {
        if(myPort == 4445) {
            for(int i = 0; i < 3; i++) {
                stenningProtocol.send(new TarryMessage("GO", i+""), 4447);
                stenningProtocol.send(new TarryMessage("GO", i+""), 4446);
            }
        }
        if(myPort == 4446) {
            for (int i = 0; i < 3; i++) {
                stenningProtocol.send(new TarryMessage("GO", i+""), 4447);
            }
        }
        while (true) {
            Map<String, Object> receiveMessage = stenningProtocol.receive();
            System.out.println("Process" + myPort + " received message " + receiveMessage.get("message").toString() + "from process" + receiveMessage.get("port"));
        }
    }
}
