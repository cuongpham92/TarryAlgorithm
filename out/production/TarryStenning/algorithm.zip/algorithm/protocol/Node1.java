package algorithm.protocol;

/**
 * Created by cuongpham on 11/21/15.
 */

import java.io.IOException;

public class Node1 {
    public static void main(String[] args) throws IOException {
        DemoProtocol node1 = new DemoProtocol("4445");
        DemoProtocol node2 = new DemoProtocol("4446");
        DemoProtocol node3 = new DemoProtocol("4447");

        node1.start();
        node2.start();
        node3.start();
    }
}
