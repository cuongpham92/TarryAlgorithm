package algorithm.protocol;

import algorithm.resource.StenningMessage;
import algorithm.resource.StenningReceivingTransporter;
import algorithm.resource.StenningSendingTransporter;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;
import java.util.*;

/**
 * Created by cuongpham on 11/28/15.
 */
public class StenningProtocol<T> {

    private DatagramSocket unicastSocket;
    private Map<Integer, StenningSendingImpl> sendingThreads;
    private Map<Integer, StenningReceivingImpl> receivingThreads;
    private int myPort;
    public StenningProtocol(int myPort) {
        try {
            this.myPort = myPort;
            unicastSocket = new DatagramSocket(myPort);
            unicastSocket.setSoTimeout(2000);
            sendingThreads = new TreeMap<>();
            receivingThreads = new TreeMap<>();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void send(T message, int port) {
        if (unicastSocket != null) {
            StenningSendingTransporter transporter = null;

            //get transpoter from stenning resource. One transporter manages a port (if it doesnt exist before, create it)
            boolean isNewPort = false;
            if (!sendingThreads.containsKey(port)) {
                transporter = new StenningSendingTransporter(0, true, new ArrayList<T>());
            }else{
                transporter =  sendingThreads.get(port).getTransporter();
            }

            //put the new message to the queue of the thread
            transporter.getMessageList().add(message);

            //if a port is new, create a corresponding thread to manage the sending channel between me and this port.
            //if this port already existed and the corresponding thread is already running, we add new message to this thread.
            if(!sendingThreads.containsKey(port)) {
                sendingThreads.put(port, new StenningSendingImpl(transporter, port));
                new Thread(sendingThreads.get(port)).start();
            }
        }
    }

    public Map<String,Object> receive() {
        try{
            if (unicastSocket != null) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                unicastSocket.receive(receivePacket);
                ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);
                ObjectInputStream ois = new ObjectInputStream(bais);
                StenningMessage message = (StenningMessage) ois.readObject();


                int port = receivePacket.getPort();

                StenningReceivingTransporter transporter = null;
                //if a port is new, create a corresponding thread to manage the receiving channel between me and this port.
                //if this receiving channel is  already existed and the corresponding thread is already running
                if (!receivingThreads.containsKey(port)) {
                    transporter = new StenningReceivingTransporter(0);
                    receivingThreads.put(port, new StenningReceivingImpl(transporter,message,port));
                    new Thread(receivingThreads.get(port)).start();
                }else{
                    receivingThreads.get(port).setMessage(message);
                }
                while(true){
                    if(receivingThreads.get(port).attachedMessage != null){
                        Map<String, Object> info = new HashMap<>();
                        info.put("message",receivingThreads.get(port).attachedMessage);
                        info.put("port",new Integer(port));
                        return  info;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Process" + myPort + " is waiting");
            e.printStackTrace();
            return  receive();
        }
        return null;
    }

    class StenningSendingImpl implements Runnable {
        private StenningSendingTransporter transporter;
        private int port;

        public StenningSendingImpl(StenningSendingTransporter transporter, int port) {
            this.transporter = transporter;
            this.port = port;
        }

        public StenningSendingTransporter getTransporter() {
            return transporter;
        }

        public void setTransporter(StenningSendingTransporter transporter) {
            this.transporter = transporter;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    if (transporter.isOk() && transporter.getSendNext() < transporter.getMessageList().size()) {
                        try {
                            StenningMessage stenningMessage = new StenningMessage("incoming", transporter.getSendNext(), transporter.getMessageList().get(transporter.getSendNext()));
                            UDPProtocol.sendUnicastObject(unicastSocket, stenningMessage, port);
                            transporter.setOk(false);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                    try {
                        byte[] receiveData = new byte[1024];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                        unicastSocket.receive(receivePacket);
                        ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);
                        ObjectInputStream ois = new ObjectInputStream(bais);
                        StenningMessage message = (StenningMessage) ois.readObject();

                        if (message.getType().equals("ack")) {
                            if (transporter.getSendNext() == message.getIndex()) {
                                transporter.setOk(true);
                              synchronized (transporter){
                                  transporter.setSendNext(transporter.getSendNext() + 1);
                              }
                                System.out.println("Process" + myPort + " received ack from Process" + receivePacket.getPort());
                            }
                        }
                    } catch (SocketTimeoutException e) {
                        System.out.println("Process" + myPort + " : no response after 2s, sending again the " + transporter.getSendNext() + "th message to Process" + port);
                        StenningMessage stenningMessage = new StenningMessage("", transporter.getSendNext(), transporter.getMessageList().get(transporter.getSendNext()));
                        UDPProtocol.sendUnicastObject(unicastSocket, stenningMessage, port);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class StenningReceivingImpl implements Runnable {
        private StenningReceivingTransporter transporter;
        private StenningMessage message;
        private int port;

        public StenningReceivingImpl(StenningReceivingTransporter transporter, StenningMessage message, int port) {
            this.transporter = transporter;
            this.message = message;
            this.port = port;
        }

        public void setMessage(StenningMessage message) {
            this.message = message;
        }

        private  T attachedMessage;

        @Override
        public void run() {
            try {
                while (true) {
                    if(message == null){
                        byte[] receiveData = new byte[1024];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                        unicastSocket.receive(receivePacket);
                        ByteArrayInputStream bais = new ByteArrayInputStream(receiveData);
                        ObjectInputStream ois = new ObjectInputStream(bais);
                        message = (StenningMessage) ois.readObject();


                    }
                    attachedMessage = null;
                    if (message.getType().equals("incoming")) {
                        if (message.getIndex() == transporter.getReceiveNext()) {
                            attachedMessage = (T) message.getMessage();
                            UDPProtocol.sendUnicastObject(unicastSocket, new StenningMessage("ack", transporter.getReceiveNext(), null), port);
                            transporter.setReceiveNext(transporter.getReceiveNext() + 1);
                        } else {

                            UDPProtocol.sendUnicastObject(unicastSocket, new StenningMessage("ack", transporter.getReceiveNext() - 1, null), port);
                        }
                    }
                    message = null;

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
