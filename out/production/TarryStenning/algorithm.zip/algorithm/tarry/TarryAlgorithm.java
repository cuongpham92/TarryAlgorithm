package algorithm.tarry;

import algorithm.protocol.Topology;

import java.io.IOException;

/**
 * Created by cuongpham on 11/25/15.
 */
public class TarryAlgorithm {
    public static void main(String[] args) throws IOException {
        Topology topology = new Topology(4445, 4);
        NodeTarryUsingStenning.setTopology(topology);

        NodeTarryUsingStenning node1 = new NodeTarryUsingStenning("4445");
        NodeTarryUsingStenning node2 = new NodeTarryUsingStenning("4446");
        NodeTarryUsingStenning node3 = new NodeTarryUsingStenning("4447");
        NodeTarryUsingStenning node4 = new NodeTarryUsingStenning("4448");

        node1.start();
        node2.start();
        node3.start();
        node4.start();

    }
}
